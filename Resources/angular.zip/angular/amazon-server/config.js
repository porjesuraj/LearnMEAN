module.exports = {
  secret: '1234567890abcdefghijklmnopqrstuvwxyz',
  emailUser: 'experiments.nihal@gmail.com',
  emailPassword: 'Indiaisbest'
}
