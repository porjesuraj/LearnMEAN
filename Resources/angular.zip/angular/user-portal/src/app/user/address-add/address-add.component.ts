import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-address-add',
  templateUrl: './address-add.component.html',
  styleUrls: ['./address-add.component.css']
})
export class AddressAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
