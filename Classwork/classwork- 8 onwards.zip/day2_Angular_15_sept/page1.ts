class Person{
    //implicit property declaration 
   name
   //explicit propery declaration
   age:number 
   email:string
   address:string

}

const p1 = new Person()
p1.name = "suraj"
p1.age = 24
p1.email = "suraj@gmail.com"
p1.address = "nasik"
console.log(p1)