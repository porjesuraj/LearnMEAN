module.exports = {
    secret: '1234567890abcdefghijklmnopqrstuvwxyz',
    emailUser : 'firstnamesuraj123@gmail.com',
    emailPassword : 'indiaIsBest'
  }