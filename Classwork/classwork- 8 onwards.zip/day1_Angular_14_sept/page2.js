let number = 100 
console.log(`number = ${number}, type = ${typeof(number)}`)

number = 'test' 
console.log(`number = ${number}, type = ${typeof(number)}`)

 number = true 
console.log(`number = ${number}, type = ${typeof(number)}`)
 number = {number : 1} 
console.log(`number = ${number}, type = ${typeof(number)}`)

