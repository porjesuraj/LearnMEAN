//for js
function add(p1, p2) {
    console.log("addition = " + (p1 + p2));
}
add(10, 30);
add(10, '30');
// need to check datatype in js
// expicit  ts
function sub(p1, p2) {
    console.log("substract = " + (p1 - p2));
}
sub(30, 10);
sub(23, 33);
//int square(int num) {return num * num }
function square(num) { return num * num; }
console.log(square(16));
console.log(square(17));
console.log(square(18));
console.log(square(19));
console.log(square(21));
console.log(square(22));
console.log(square(23));
console.log(square(24));
console.log(square(26));
