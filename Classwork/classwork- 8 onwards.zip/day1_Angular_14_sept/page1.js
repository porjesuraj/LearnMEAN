//number
var num = 100;
console.log("num = " + num + ", type = " + typeof (num));
var num2 = 10.56;
console.log("num = " + num2 + ", type = " + typeof (num2));
//string
var string = "steve";
console.log("num = " + string + ", type = " + typeof (string));
var string2 = 'jobs';
console.log("num = " + string2 + ", type = " + typeof (string2));
var string3 = "coutnry\nindia";
console.log("num = " + string3 + ", type = " + typeof (string3));
//boolean
var canVote = true;
console.log("canVote = " + canVote + ", type od = " + typeof (canVote));
//undefined
var myvar;
console.log("my var = " + myvar + ", type of = " + typeof (myvar));
// object
var person = { person1: "suraj", city: "pune " };
console.log("my person = " + person + ", type of = " + typeof (person));
//cannot be done as datatype cant change
//num = 'test'
num = 500;
console.log("num = " + num + ", type = " + typeof (num));
