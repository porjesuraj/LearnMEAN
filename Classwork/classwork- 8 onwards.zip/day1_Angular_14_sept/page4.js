//int num = 100 ; in C 
//const num = 100 // implicit in js
var num = 100;
console.log("num = " + num + " , typeof " + typeof (num));
//num = 100
//num = "str" not assignable to type "number"
var firstName = "steve";
console.log("firstName = " + firstName + " , typeof " + typeof (firstName));
var myvar;
console.log("myvar = " + myvar + " , typeof " + typeof (myvar));
var can = true;
console.log("can = " + can + " , typeof " + typeof (can));
var person = { name: "perosn1", age: 40 };
console.log("perosn = " + person + ", type of " + typeof (person));
console.log(person);
