function add(a, b) {
    return a + b;
}
;
console.log(add("suraj", "porje"));
console.log(add(30, 20));
